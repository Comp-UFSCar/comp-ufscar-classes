/*
 * Exemplo de uso de mem�ria "compartilhada".
 * Cria��o de um segmento em um �nico processo e verifica��o de endere�os.
 */ 
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>

#define SHMSZ 27 /* Ser� arredondado para um m�ltiplo de PAGE_SIZE */

char str_global[10];

int main() {
  int shmid;
  key_t key;
  char str_local[10];
  char *shm;
  
  /* Chave arbitr�ria para o segmento compartilhado */
  key = 5677;

  /* Cria��o do segmento de mem�ria e obten��o do seu identificador. */
  if ((shmid = shmget(key, SHMSZ, IPC_CREAT | 0666)) < 0) {
    perror("shmget");
    exit(1);
  }

  /* Segmento � associado ao espa�o de endere�amento */
  if ((shm = shmat(shmid, NULL, 0)) == (char *) -1) {
    perror("shmat");
    exit(1);
  }

  printf("str_local  = %p\n", str_local);
  printf("shm        = %p\n", shm);  
  printf("str_global = %p\n", str_global);
  printf("main       = %p\n", main);

  return 0;
}
