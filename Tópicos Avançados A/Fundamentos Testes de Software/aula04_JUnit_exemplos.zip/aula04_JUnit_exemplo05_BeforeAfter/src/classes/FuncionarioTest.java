package classes;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class FuncionarioTest {

	Funcionario func;
	
	@Before
	public  void criaFuncionario() {
		func = new Funcionario("Fabiano", "0000", 0);
	}
	
	@After
	public  void limpaFuncionario() {
		func = null;
	}
	
	@Test
	public void test01() {
		func.setSalario(1200);
		double resultado = func.calculaHoraExtra(10);
		assertEquals(50, resultado, 0);
	}

	@Test
	public void test02() {
		func.setSalario(1500);
		double resultado = func.calculaHoraExtra(20);
		assertEquals(125, resultado, 0);
	}
	
}
