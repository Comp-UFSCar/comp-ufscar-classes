/*
 * Qual abordagem para aloca��o?
 */

#include <stdlib.h>
#include <stdio.h>

int main() {
  int *s1, *s2, *s3, *s4, *s5, *s6;

  s1 = (int *) malloc (sizeof(int) * 100);
  printf ("s1: %p\n", (void*) s1);
  s2 = (int *) malloc (sizeof(int) * 50);
  printf ("s2: %p\n", (void*) s2);
  s3 = (int *) malloc (sizeof(int) * 40);
  printf ("s3: %p\n", (void*) s3);
  s4 = (int *) malloc (sizeof(int) * 100);
  printf ("s4: %p\n", (void*) s4);
  free(s1);
  free(s3);
  s5 = (int *) malloc (sizeof(int) * 2);
  printf ("s5: %p\n", (void*) s5);

  s6 = (int *) malloc (sizeof(int) * 50);
  printf ("s6: %p\n", (void*) s6);

  return 0;
}
