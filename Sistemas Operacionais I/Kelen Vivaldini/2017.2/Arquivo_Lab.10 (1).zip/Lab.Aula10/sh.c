/*
 * Exemplo de uso de mem�ria "compartilhada". Vamos
 * verificar a aloca��o de uma p�gina.
 */ 
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define SHMSZ 27 /* Ser� arredondado para um m�ltiplo de PAGE_SIZE */

char str_dados[10];

int main() {
  int shmid;
  key_t key;
  char str_pilha[10];
  char *shm;
  int pagesize = getpagesize();

  /* Chave arbitr�ria para o segmento compartilhado */
  key = 5677;

  /* Cria��o do segmento de mem�ria e obten��o do seu identificador. */
  if ((shmid = shmget(key, SHMSZ, IPC_CREAT | 0666)) < 0) {
    perror("shmget");
    exit(1);
  }

  /* Tentativa de associa��o pr�ximo � �rea de dados. */
  if ((shm = shmat(shmid, str_dados+0x10000, SHM_RND)) == (char *) -1) {
    printf("shmat at 0x%x\n", (unsigned int) str_dados+0x1000);
    perror("shmat");
    }


  printf("str_pilha  = 0x%x\n", (unsigned int) str_pilha);
  printf("shm        = 0x%x\n", (unsigned int) shm);  
  printf("str_dados = 0x%x\n",  (unsigned int) str_dados);
  printf("main       = 0x%x\n", (unsigned int) main);

  shm[pagesize - 1] = 0;
  shm[pagesize] = 0;


  return 0;
}
