/*
 * Exemplo simples de uso do qsort.
 *    void qsort(void *base, size_t nmemb, size_t size, 
 *         int (*compar)(const void *, const void *));
 */
#include <stdio.h>
#include <stdlib.h>

int compara_cresc(const void* pa, const void* pb) {
  int a = * (int*) pa;
  int b = * (int*) pb;
  return a - b;
}

int compara_decresc(const void* pa, const void* pb) {
  return *(int*)pb - *(int*)pa;
}

void imprime(int numeros[], int tam) {
  int i;
  for (i = 0; i < tam; i++) {
    printf("%d ", numeros[i]);
  }
  printf("\n");
}

int main() {
  int numeros[] = { 14, -1, 10, 5, 12, 18, -8, 3};
  int tamanho = sizeof(numeros)/sizeof(int);
  
  qsort (numeros, tamanho, sizeof(int), compara_cresc);
  imprime(numeros, tamanho);
  
  qsort (numeros, tamanho, sizeof(int), compara_decresc);
  imprime(numeros, tamanho);
  
  return 0;
} 
