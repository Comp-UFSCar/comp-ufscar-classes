#include <stdio.h>
#include <stdlib.h>
     
int main (void)
{
  FILE *input;
  char s[5];
  int i=0;
  
  input = popen ("yes", "r");
  while(1) {
    fscanf(input, "%s", s);
    printf("%d:%s\n", i++, s);
  }
}
