package t1;

public enum Tipo {
    VARIAVEL, FUNCAO
}
