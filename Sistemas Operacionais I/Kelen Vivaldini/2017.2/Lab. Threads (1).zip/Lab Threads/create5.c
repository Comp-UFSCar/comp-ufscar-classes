/*
 * Passagem de parâmetros para a thread. Cada thread terá um identificador único!
 * Como melhorar esta abordagem? 
 */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define N_THR 10

void* f_thread(void *v) {
  int thr_id; 
  sleep(1);
  thr_id = *(int*) v;
  printf("Thread %d.\n", thr_id);  
  return NULL; 
} 

int main() {
  pthread_t thr[N_THR];
  int i, *p_id;
  
  for (i = 0; i < N_THR; i++) {
    p_id = (int*) malloc(sizeof(int));
    *p_id = i;
    pthread_create(&thr[i], NULL, f_thread, (void*) p_id);
  }

  for (i = 0; i < N_THR; i++) 
    pthread_join(thr[i], NULL); 

  
  return 0;
}
