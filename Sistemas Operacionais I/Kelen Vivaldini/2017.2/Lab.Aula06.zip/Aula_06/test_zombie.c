/*
It is necessary open three other terminals separately and type the commands: 

Compile: gcc -o test_zombies.c test_zombies

1: watch -n 1 'ps -o pid, uname, comm -C test_zombies'
2: ./test_zombies
3: ps xl    Obs. After the code is executed

Adapted from Jair Dias de Oliveira Junior  

Prof Kelen Vivaldini
September 2017
*/

#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>   
#include <stdlib.h>  

int main(int argc, char *argv[]){
  pid_t child_pid;

	//Create child process
	child_pid = fork();
	if( child_pid == 0 ){

		// Child process is finished
		_exit(EXIT_SUCCESS);

	}
	else if( child_pid < 0 ){

		// error to crete the child process
		perror("fork");
		exit(EXIT_FAILURE);

	}
	else{

		// Parent process sleep 60 seconds
		fprintf(stdout, "Parent process");
		fprintf(stdout, "PID: %d. \n", (int)getpid() );
		fprintf(stdout, "Created child process");
		fprintf(stdout, "PID: %d. \n", (int)child_pid );
		sleep(60);

	}

	return 0;

}
