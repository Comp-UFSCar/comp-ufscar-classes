/*
 * Exemplo para create e join.  As threads executarão o
 * suposto trabalho duro de forma paralela ou sequencial?
 */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define N_THR 10

void* f_thread(void *v) {
  int thr_id = (int) v;
  pthread_t thr;

  if (thr_id + 1 < N_THR) 
    pthread_create(&thr, NULL, f_thread, (void*) thr_id + 1);

  if (thr_id + 1 < N_THR)
    pthread_join(thr, NULL);

  printf("Thread %d iniciou o seu trabalho.\n", thr_id);

  /* Suponha muito trabalho aqui !!! */
  sleep(random() % 3);

  
  printf("Thread %d terminou o seu trabalho.\n", thr_id);

  return NULL; 
} 

int main() {
  pthread_t thr;
  
  pthread_create(&thr, NULL, f_thread, (void*) 0);

  /* Suponha muito trabalho aqui !!! */
  sleep(random() % 3);

  
  pthread_join(thr, NULL);
  
  return 0;
}
