/**
 * 
 */
package util;

/**
 * @author ferrari
 *
 */
public class CalculatorWithExceptionTest {

	private int nbErrors = 0;

	public void testAdd() {
		Calculator calculator = new Calculator();
		double result = calculator.add(10, 50);
		if (result != 60) {
			throw new RuntimeException("Bad result: " + result);
		}
	}
	
	public void testAdd_2() {
		Calculator calculator = new Calculator();
		double result = calculator.add(0, 1000);
		if (result != 1000) {
			throw new RuntimeException("Bad result: " + result);
		}
	}


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		CalculatorWithExceptionTest test = new CalculatorWithExceptionTest();
		
		try { 
			test.testAdd(); 
		}
		catch (Throwable e) {
			test.nbErrors++;
			e.printStackTrace();
		} 
		

		try { 
			test.testAdd_2(); 
		}
		catch (Throwable e) {
			test.nbErrors++;
			e.printStackTrace();
		} 
		
		if (test.nbErrors > 0) {
			throw new RuntimeException("There were " + 
					test.nbErrors + " error(s)");
		}
	}

}

