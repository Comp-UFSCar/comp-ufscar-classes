/*
 * Execução de funções.
 */ 

#include <stdio.h>

void hello() {
  printf("hello\n");
}

void goodbye() {
  printf("goodbye\n");
}

int main() {
  int *j;
  int i;
  void (*funcao)();

  j = &i;
  funcao = hello;
  funcao();
  funcao = goodbye;
  funcao();
  return 0;
}
