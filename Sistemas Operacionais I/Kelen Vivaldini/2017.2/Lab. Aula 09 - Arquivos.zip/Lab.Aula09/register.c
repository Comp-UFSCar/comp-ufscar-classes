
volatile int j;
int k;


int main() {
  register int i;


  for (i = 10; i < 100; i++);
    
  for (j = 20; j < 200; j++);

  for (k = 30; k < 300; k++);

  return 0;
}
