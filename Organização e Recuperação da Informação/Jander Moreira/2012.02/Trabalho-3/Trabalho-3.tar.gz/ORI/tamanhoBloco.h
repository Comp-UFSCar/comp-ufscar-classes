/* 
 * File:   tamanhoBloco.h
 * Author: thales
 *
 * Created on January 23, 2013, 7:45 PM
 */

#ifndef TAMANHOBLOCO_H
#define	TAMANHOBLOCO_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

struct stat fi;
    
#ifdef	__cplusplus
}
#endif

#endif	/* TAMANHOBLOCO_H */

