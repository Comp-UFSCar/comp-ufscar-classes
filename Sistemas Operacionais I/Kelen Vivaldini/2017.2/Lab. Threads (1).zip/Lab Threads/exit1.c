/*
 * Programa simples para verifica��o de c�digo de retorno.
 * Execute no gdb e em background.
 */
#include <stdio.h>
#include <stdlib.h>

void f() {
  exit(1);
}

int main() {

  f();
  
  return 2; /* Nunca executado. */
}
