/*
 * Cria��o de uma nova thread, com envio de valor de retorno.
 */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct {
  int id;
  int status;
} Retorno;

Retorno retorno; /* Vari�vel global */

void* f_thread(void *v) {
  int thr_id = *(int *) v;

  printf("Thread %d.\n", thr_id);
  retorno.id = thr_id;
  retorno.status = 0; /* OK */
  return (void*) &retorno;
}

int main() {
  pthread_t thr;
  int thr_id = 1;
  Retorno* p_retorno;

  pthread_create(&thr, NULL, f_thread, (void*) &thr_id);
  pthread_join(thr, (void**) &p_retorno);

  printf("Valor de retorno: id = %d e status = %d\n", 
	 p_retorno->id, p_retorno->status);

  return 0;
}
