/*
  This program creates a child process through the fork () call and waits for its execution to end through the wait () call. There is a global variable and a local variable and their respective values are changed within the child process to verify that this change has no effect on the parent process. Adapted from Jair Dias de Oliveira Junior

Prof Kelen Vivaldini
September 2017
*/

#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>   
#include <stdlib.h>  
#include <sys/wait.h>
#include <string.h>


int globalVariable = 50;
char globalIdentifier[20];


int main(int argc, char *argv[]){
  pid_t child_pid;
  int status, localVariable = 10;

  char localIdentifier[20];
  strcpy(localIdentifier , "To learn SO");
	// Create child Process
	child_pid = fork();


	if( child_pid == 0 ){

		// Child Process
		localVariable = 25;
		globalVariable = 91;
		strcpy(localIdentifier , "SO 1");
		strcpy(globalIdentifier , "UFSCar ");

		fprintf(stdout, "Child process\n");
		fprintf(stdout, "PID: %d.\n", (int)getpid() );
		fprintf(stdout, "Parent PID: %d.\n", (int)getppid() );
		fprintf(stdout, "Local variable: %d.\n", localVariable );
		fprintf(stdout, "Global variable: %d.\n", globalVariable );
		fprintf(stdout, "Local variable: %s.\n", localIdentifier);
		fprintf(stdout, "Global variable: %s.\n", globalIdentifier );
		_exit(EXIT_SUCCESS);

	}
	else if( child_pid < 0 ){

		// error to crete the child process
		perror("fork");
		exit(EXIT_FAILURE);

	}
	// Parent process
	else{

		// Waits for child process to finish and receive status
		wait(& status);

		if( WIFEXITED(status) )
			fprintf(stdout, "Child exit status: %d.\n", WEXITSTATUS(status) );
		else
			fprintf(stdout, "Child process terminated with error.\n");

		fprintf(stdout, "Parent process\n");
		fprintf(stdout, "PID: %d.\n", (int)getpid() );
		fprintf(stdout, "Child PID: %d.\n", (int)child_pid );
		fprintf(stdout, "Local variable: %d.\n", localVariable );
		fprintf(stdout, "Global variable: %d.\n", globalVariable );
		fprintf(stdout, "Local variable: %s.\n", localIdentifier);
		fprintf(stdout, "Global variable: %s.\n", globalIdentifier );

	}

	return 0;

}
