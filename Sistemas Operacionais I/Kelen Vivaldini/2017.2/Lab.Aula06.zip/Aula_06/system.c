/*
  
Prof Kelen Vivaldini
September 2017
*/

#include <stdio.h>
#include <stdlib.h>
main()
{
   system("ls -l");
   printf("Command done!");

}
