// ENCODE.CPP - Copy and encrypt a file.

// Updated 6/30/05

#include <iostream>
#include <fstream>
#include "translat.h"

using namespace std;

int main( int argcount, char * args[] ) 
{  
	const int BUFSIZE = 2000;
	char buffer[BUFSIZE];
	unsigned int count;			// character count
  
	unsigned char encryptCode;
	cout << "Digite a chave p/ codificar [0-255]: ";
	cin >> encryptCode;

	// para codificar:
	ifstream infile("mensagem.txt", ios::binary );
    ofstream outfile("segredo.txt", ios::binary );

	// para decifrar:
	// ifstream infile("segredo.txt", ios::binary );
	// ofstream outfile("decifrado.txt", ios::binary );


	cout << "Codificando mensagem..." << endl;

	while (!infile.eof() )
	{
		infile.read(buffer, BUFSIZE );
		count = infile.gcount();
		TranslateBuffer(buffer, count, encryptCode);
		outfile.write(buffer, count);
	}

	outfile.flush();
	outfile.close();


	// para decifrar:
	ifstream infile2("segredo.txt", ios::binary );
	ofstream outfile2("decifrado.txt", ios::binary );


	cout << "Decodificando mensagem..." << endl;

	while (!infile2.eof() )
	{
		infile2.read(buffer, BUFSIZE );
		count = infile2.gcount();
		TranslateBuffer(buffer, count, encryptCode);
		outfile2.write(buffer, count);
	}

	outfile2.flush();
	outfile2.close();


	return 0;
}