/*
 *  Exemplo de uso da fun��o popen
 */ 
#include <stdio.h>
#include <stdlib.h>
     
int main (void) {
  FILE *output;
  int i=0;
  
  output = popen ("more", "w");
  if (!output) {
    fprintf (stderr, "erro em popen.\n");
    return EXIT_FAILURE;
  }
  
  while(1)
    fprintf(output, "%d: teste popen\n", i++);

  return 0;
}
