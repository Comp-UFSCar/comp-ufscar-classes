/*
 * Cada thread tem um identificador único. Vamos
 * verificar os endereços das pilhas de execução.
 */ 
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define N_THR 10

void* f_thread(void *v) {
  int thr_id;
  thr_id = *(int *) v;
  printf("Thread %d. Endereço de thr_id: %p \n", thr_id, &thr_id);
  return NULL;
}

int main() {  
  pthread_t thr[N_THR];
  int i, id[N_THR];

  for (i = 0; i < N_THR; i++) {
    id[i] = i;
    pthread_create(&thr[i], NULL, f_thread, (void*) &id[i]);
  }

  for (i = 0; i < N_THR; i++) 
    pthread_join(thr[i], NULL);
  return 0;
}
