// main.cpp - Testing FindArray and AsmFindArray.

#include <iostream>
#include <time.h>
#include "asmFatorial.h"
using namespace std;

int main()
{
	unsigned long N= 6;

	asmFatorial(N);


	return 0;
}