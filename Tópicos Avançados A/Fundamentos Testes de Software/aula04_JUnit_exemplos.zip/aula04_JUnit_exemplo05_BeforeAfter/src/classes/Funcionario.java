/**
 * 
 */
package classes;

/**
 * @author ferrari
 *
 */
public class Funcionario {
	
	String nome;
	String CPF;
	double salario;
	
	public Funcionario(String n, String cpf, double s) {
		this.nome = n;
		this.CPF = cpf;
		this.salario = s;
	}
	
	
	public void setSalario(double s) {
		this.salario = s;
	}
	
	public double calculaHoraExtra(double horas) {
		
		double valorHorasExtras = 
				(this.salario/30)/8 * horas;
		
		return valorHorasExtras;
	}

}
