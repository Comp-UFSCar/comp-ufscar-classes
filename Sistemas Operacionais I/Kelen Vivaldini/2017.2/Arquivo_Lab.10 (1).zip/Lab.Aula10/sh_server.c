/*
 * Exemplo de uso de mem�ria compartilhada.  
 */ 
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>

#define SHMSZ 27 /* Ser� arredondado para um m�ltiplo de PAGE_SIZE */

char str_global[10];

int main() {
  int shmid;
  key_t key;
  char *shm;
  char c, *s;
  
  /* Chave arbitr�ria para o segmento compartilhado */
  key = 5679;

  /* Cria��o do segmento de mem�ria e obten��o do seu identificador. */
  if ((shmid = shmget(key, SHMSZ, IPC_CREAT | 0666)) < 0) {
    perror("shmget");
    exit(1);
  }
  
  /* Tentativa de associa��o pr�ximo � �rea de dados. */
  if ((shm = shmat(shmid, str_global+0x10000, SHM_RND)) == (char *) -1) {
    printf("shmat at %p\n", str_global+0x1000);
    perror("shmat");
    }

  /* Preenche o segmento com o alfabeto */
  s = shm;
  for (c = 'a'; c <= 'z'; c++)
    *s++ = c;
  *s = '\0';

  printf("Processo servidor: %s\n", shm);
  printf("shm  = %p\n",shm);
  
  return 0;
}
