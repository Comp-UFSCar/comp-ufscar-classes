/*
  
Prof Kelen Vivaldini
September 2017
*/


#include <unistd.h>
main()
{
   execl("/bin/ls", "/bin/ls", "-r", "-t", "-l", (char *) 0);
}

