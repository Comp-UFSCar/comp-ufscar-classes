/*
    Arquivo de configuração para utilização da árvore
    Mudança da ordem da árvore deve ser feita aqui.
*/

#define ORDEM 5 // basta alterar o valor da Ordem para mudar o código
#define MAXIMO_CHAVES (ORDEM-1)
#define MINIMO_CHAVES ((ORDEM-1)/2)
#define TRUE 0
#define FALSE -1
