// findarr.h

extern "C" {

void asmFatorial( long n );
// Assembly language version


}