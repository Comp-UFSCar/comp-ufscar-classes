/*
 * Exemplo de uso de mem�ria compartilhada.
 * Pai e filho ir�o se sincronizar por meio de espera ocupada. 
 */ 
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define SHMSZ 2 

int main() {
  int shmid;
  key_t key;
  char *shm;
  
  /* Chave arbitr�ria para o segmento compartilhado */
  key = 5677;

  /* Cria��o do segmento de mem�ria e obten��o do seu identificador. */
  if ((shmid = shmget(key, SHMSZ, IPC_CREAT | 0666)) < 0) {
    perror("shmget");
    exit(1);
  }

  /* Segmento � associado ao espa�o de endere�amento */
  if ((shm = shmat(shmid, NULL, 0)) == (char *) -1) {
    perror("shmat");
    exit(1); 
  } 

  shm[0] = '\0';
  shm[1] = '\0';

  if (fork() != 0) {
    shm[0] = '*';
    printf("Esperando o filho\n");
    while (shm[1] != '*')
      sleep(1);
  }
  else {
    sleep(10);
    shm[1] = '*';
    printf("Esperando o pai\n");
    while (shm[0] != '*')
      sleep(1);
  }    

  shmctl(shmid, IPC_RMID, NULL);      
  shmdt(shm);
    
  return 0;
}
