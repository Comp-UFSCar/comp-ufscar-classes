/*
 * Criação de uma nova thread, com passagem de identificador como
 * parâmetro.
 */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

void* f_thread(void *v) {
  int id = *(int *) v;
  
  printf("Thread id=%d\n", id);
  return NULL;
}

int main() {
  pthread_t thr;
  int thr_id = 1;

  pthread_create(&thr, NULL, f_thread, (void*) &thr_id);
  pthread_join(thr, NULL);
    
  return 0;
}
