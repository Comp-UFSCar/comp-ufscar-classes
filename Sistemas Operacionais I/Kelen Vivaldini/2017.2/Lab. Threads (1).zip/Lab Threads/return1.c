/*
 * Programa simples para verificação de código de retorno.
 * Execute no gdb e em background.
 */
#include <stdio.h>
#include <stdlib.h>

int main() {

  return 1;

}
