/**
 * 
 */
package util;

/**
 * @author ferrari
 *
 */
public class CalculatorTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	    Calculator calculator = new Calculator();
	    double result = calculator.add(10,50);
	    if (result != 60) {
	      System.out.println("Bad result: " + result);
	    }
	    
	    result = calculator.add(0, 1000);
	    if (result != 1000) {
		      System.out.println("Bad result: " + result);
		    }
	    
	  }

}
