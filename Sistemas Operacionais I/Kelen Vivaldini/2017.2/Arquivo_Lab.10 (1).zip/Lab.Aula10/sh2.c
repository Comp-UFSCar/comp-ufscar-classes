/*
 * Exemplo de uso de mem�ria compartilhada.  Associa��o do mesmo
 * segmento pr�ximo � �rea de pilha e pr�ximo � �rea de dados.
 */ 
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>

#define SHMSZ 27 /* Ser� arredondado para um m�ltiplo de PAGE_SIZE */

char str_global[10];

int main() {
  int shmid;
  key_t key;
  char str_local[10];
  char *shm_dados, *shm_pilha;
  char c, *s;
  
  /* Chave arbitr�ria para o segmento compartilhado */
  key = 5677;

  /* Cria��o do segmento de mem�ria e obten��o do seu identificador. */
  if ((shmid = shmget(key, SHMSZ, IPC_CREAT | 0666)) < 0) {
    perror("shmget");
    exit(1);
  }
  
  /* Tentativa de associa��o pr�ximo � �rea de pilha. */
  if ((shm_pilha = shmat(shmid, str_local-0x100000, SHM_RND)) == (char *) -1) {
    printf("shmat at %p\n",  str_local-0x100000);
    perror("shmat");
    exit(1);
  }
  
  /* Tentativa de associa��o pr�ximo � �rea de dados. */
  if ((shm_dados = shmat(shmid, str_global+0x10000, SHM_RND)) == (char *) -1) {
    printf("shmat at %p\n",  str_global+0x1000);
    perror("shmat");
    }

  
  printf("str_local  = %p\n", str_local);
  printf("shm_pilha  = %p\n", shm_pilha);
  printf("shm_dados  = %p\n", shm_dados);    
  printf("str_global = %p\n", str_global);
  printf("main       = %p\n", main);

  /* Preenche o segmento com o alfabeto */
  s = shm_pilha;
  for (c = 'a'; c <= 'z'; c++)
    *s++ = c;
  *s = '\0';

  /* Verifica o preenchimento nos dois endere�o */
  printf("SHM_Pilha: %s\n", shm_pilha);
  printf("SHM_Dados: %s\n", shm_dados);
  
  return 0;
}
