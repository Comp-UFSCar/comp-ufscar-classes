/*
 * Cria��o de uma nova thread, com envio de valor de retorno. 
 *
 * Nesta abordagem, a nova thread retorna um apontador para um inteiro
 * que foi alocado dinamicamente.
 */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

typdef struct {
  int x;
  int y;
} Exemplo;

void* f_thread(void *v) {
  int *retorno = (int *) malloc (sizeof(int));
  *retorno = 256;
  printf("Nova Thread ir� retornar um apontador para um inteiro que cont�m 256.\n");
  return (void*) retorno;
}

int main() {
  pthread_t thr;
  Exemplo arg, ret;

  arg.x = 1;
  arg.y = 1;

  pthread_create(&thr, NULL, f_thread, NULL);
  
  pthread_join(thr, (void**) &retorno_thr);

  printf("Valor de retorno (apontador): %p\n", retorno_thr);
  printf("Valor de retorno (conte�do): %d\n", *retorno_thr);

  free(retorno_thr); 
  
  return 0;
}
