/*
 * Criação de uma nova thread. Será que ela será sempre executada?
 */
#include <pthread.h>
#include <stdio.h>


void* f_thread(void *v) {
  printf("Nova Thread.\n");
  return NULL;
}

int main() {
  pthread_t thr0;

  if (pthread_create(&thr0, NULL, f_thread, NULL))
    fprintf(stderr, "Erro na criação da thread. \n");

  return 0;
}
