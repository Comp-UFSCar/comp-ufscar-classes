/*
vfork - create a child process and block parent 
Prof Kelen Vivaldini
September 2017
*/

#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>   
#include <stdlib.h>  
#include <string.h> 


int globalVariable = 2;

main()
{
   char Identifier[20];
   int  iStackVariable = 20;

   pid_t pid = vfork();
   if (pid == 0)                // child
   {
      // Code only executed by child process
      strcpy(Identifier , "Child Process: ");
      globalVariable++;
      iStackVariable++;
      printf("\n %s (pid = %d)", Identifier, getpid());
      printf("\n  Global variable: %d", globalVariable);
      printf("\n  Stack variable: %d" , iStackVariable );

    }
    else if (pid < 0)            // failed to fork
    {
        printf ("\n Failed to fork");
        exit(1);
        // Throw exception
    }
    else                                   // parent
    {
      // Code only executed by parent process
       strcpy(Identifier, "Parent Process:");
    }

    // Code executed by both parent and child.
    printf("\n %s (pid = %d)", Identifier, getpid());
    printf("\n  Global variable: %d", globalVariable);
    printf("\n  Stack variable: %d" , iStackVariable );
    exit(0);	
}
