/*
 * Uma thread pode corromper a pilha de outra thread?
 */ 
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define N_THR 10

void  g() {
  int v[1024*1024];   /* Tamanho de v é muito importante... */
  printf("Endereço de v: %p \n", v);
  g();
}

void* f_thread(void *v) {
  int thr_id;
  thr_id = *(int *) v;
  printf("Thread %d. Endereço de thr_id: %p \n", thr_id, &thr_id);
  if (thr_id == 0) {
    sleep(3);
    g();
  }
  return NULL;
}

int main() {  
  pthread_t thr[N_THR];
  int i, id[N_THR];

  for (i = 0; i < N_THR; i++) {
    id[i] = i;
    pthread_create(&thr[i], NULL, f_thread, (void*) &id[i]);
  }

  for (i = 0; i < N_THR; i++) 
    pthread_join(thr[i], NULL);
  return 0;
}
