package util;

import org.junit.Test;

import static org.junit.Assert.*;

public class CalculatorTest {

	@Test
	public void testAdd() {
		Calculator calculator = new Calculator();
		double result = calculator.add(2, 2);
		assertEquals(4, result, 0);
	}

	
	@Test
	public void testAdd_2() {
		Calculator calculator = new Calculator();
		double result = calculator.add(0, 1000);
		assertEquals(1000, result, 0);
	}
	
	
	@Test
	public void testAdd_3() {
		Calculator calculator = new Calculator();
		double result = calculator.add(0, 0);
		assertEquals(0, result, 0);
	}
	
	
	@Test
	public void testMultiply() {
		Calculator calculator = new Calculator();
		double result = calculator.multiply(3, 5);
		assertEquals(15, result, 0);
	}

	@Test
	public void testDivide() {
		Calculator calculator = new Calculator();
		double result = calculator.divide(10, 3);
		assertEquals(3.3333333, result, 0.005);
		
	}
	
	@Test
	public void testNotNull() {
		Calculator calculator = new Calculator();
		double result = calculator.add(1, 5);
		assertEquals(6,  result, 0);
	}

	@Test(expected = java.lang.RuntimeException.class)
	public void testQualquerCoisa()  {
		Calculator calculator = new Calculator();
		try {
			calculator.qualquerCoisa();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}
	
}
