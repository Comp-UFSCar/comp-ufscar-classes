package util;
/**
 * 
 */


/**
 * @author ferrari
 *
 */
public class Calculator {

	public Calculator() {}
	
	public double add(double op1, double op2) {
		return op1 + op2;
	}
	
	public double multiply(double op1, double op2) {
		return op1 * op2;
	}
	
	public double divide(double op1, double op2) {
		return op1 / op2;
	}
	
	public void qualquerCoisa() throws Exception {
		throw new RuntimeException();
	}
	
}
