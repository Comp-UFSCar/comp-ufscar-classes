/*
 * Passagem de parâmetros para a thread. Será que cada thread
 * terá um identificador único?
 */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define N_THR 10


void* f_thread(void *v) {
  int *p_id = (int *) v;
  printf("Thread %d.\n", *p_id);  
  return NULL; 
} 

int main() {
  pthread_t thr[N_THR];
  int i, j;

  for (i = 0; i < N_THR; i++) 
    pthread_create(&thr[i], NULL, f_thread, (void*) &i);

  for (j = 0; j < N_THR; j++) 
    pthread_join(thr[j], NULL); 

  return 0;
}
