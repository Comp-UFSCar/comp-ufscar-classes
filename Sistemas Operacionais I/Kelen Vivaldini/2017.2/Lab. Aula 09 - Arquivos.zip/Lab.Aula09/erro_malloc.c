/*
 * Qual erro pode acontecer?
 */

#include <stdlib.h>

int main() {
  int *s1, *s2;
  int i;

  s1 = (int *) malloc (sizeof(int) * 20);
  s2 = (int *) malloc (sizeof(int) * 20);

   for (i = 0; i < 50; i++)
    s1[i] = 0;

  for (i = 0; i < 30; i++)
  s2[i] = 7; 
  
  free(s2);

  return 0;                 
}
