/*
 * Programa simples para verificação de código de retorno.
 * Execute no gdb e em background.
 */
#include <stdio.h>
#include <stdlib.h>

void f() {
  exit(0);
}

int main() {

  f();
    
  return 1; /* Nunca executado. */
}
