/*
  
Prof Kelen Vivaldini
September 2017
*/


#include <unistd.h>
main()
{
   char *args[] = {"/bin/ls", "-r", "-t", "-l", (char *) 0 };

   execv("/bin/ls", args);
}

