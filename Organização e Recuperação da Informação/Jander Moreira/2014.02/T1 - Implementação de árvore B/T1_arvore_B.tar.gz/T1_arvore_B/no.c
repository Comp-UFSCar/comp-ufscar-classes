#include "no.h"

tNo * inicializaNo()
{
    int i = 0;
    // Alocação dinâmica na memória
    tNo *novo = (tNo *) malloc(sizeof(tNo));

    for(i = 0; i < MAXIMO_CHAVES; i++)
        inicializaDado(&novo->dado[i]);

    for(i = 0; i < ORDEM; i++)
        novo->pont[i] = 0;

    novo->cont = 0;

    return novo;
}

int noCheio(tNo *no)
{
    if(no->cont == MAXIMO_CHAVES)
        return TRUE;
    else
        return FALSE;
}

int ehFolha(tNo *no)
{
    int i = 0;
    for(i = 0; i < ORDEM; i++)
    {
        if(no->pont[i] != 0)
            return FALSE;
    }
    return TRUE;
}

tNo * escolheFilho(tNo *no, int chave)
{
    int i = 0;
    for(i = 0; i < no->cont; i++)
    {
        if(chave < no->dado[i].chave)
            return no->pont[i];
    }
    return no->pont[i];
}

int insereChave(tNo *no, tDado dado){
    if(no == 0) // arvore vazia
    {
        // Criacao do noh raiz
        tNo *novoNo = inicializaNo();
        int i;
        for(i = 0 ; i < MAXIMO_CHAVES; i++)
            printf("\t    %d", novoNo->dado[i]);

        printf("\n");
        for(i = 0 ; i < ORDEM; i++)
            printf("\t%d", novoNo->pont[i]);
        //no->cont += 1;
        //no->dado[0] = dado;
        return TRUE;
    }
    else
    {

    }

}

int buscaChave(tNo *no, int chave){
    int i = 0;

    if (no == 0)    // ponteiro nulo: arvore vazia
        return FALSE;
    else
    {
        // verifica todas chaves dentro do no
        for(i = 0; i < no->cont; i++)
        {
            if(no->dado[i].chave == chave)
                return TRUE;    // se encontrar no noh, retorna TRUE
        }
        if (ehFolha(no) == TRUE)    // se for folha
            return FALSE;
        else
            return buscaChave(escolheFilho(no, chave), chave);  // fazer busca no noh filho correto
    }
}



int removeChave(){

}
