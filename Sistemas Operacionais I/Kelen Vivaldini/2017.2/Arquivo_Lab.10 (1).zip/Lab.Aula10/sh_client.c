/*
 * Exemplo de uso de mem�ria compartilhada.  
 */ 
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>

#define SHMSZ 27 /* Ser� arredondado para um m�ltiplo de PAGE_SIZE */

char str_global[10];

int main() {
  int shmid;
  key_t key;
  char str_local[10];
  char *shm;
  
  /* Chave arbitr�ria para o segmento compartilhado */
  key = 5679;

  /* Cria��o do segmento de mem�ria e obten��o do seu identificador. */
  if ((shmid = shmget(key, SHMSZ, 0666)) < 0) {
    perror("shmget");
    exit(1);
  }
  
  /* Tentativa de associa��o pr�ximo � �rea de pilha. */
  if ((shm = shmat(shmid, str_local-0x100000, SHM_RND)) == (char *) -1) {
    printf("shmat at %p\n", str_local-0x100000);
    perror("shmat");
    exit(1);
  }
  
  printf("Processo cliente: %s\n", shm);
  printf("shm  = %p\n", shm);

  shmctl(shmid, IPC_RMID, NULL);
   
  return 0;
}
