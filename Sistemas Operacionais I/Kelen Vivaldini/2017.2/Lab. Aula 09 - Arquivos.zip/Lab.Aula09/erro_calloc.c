/*
 * Qual erro pode acontecer? (vers�o calloc)
 */

#include <stdlib.h>

int main() {
  int *s1, *s2;
  int i;

  s1 = (int *) calloc (62, sizeof(int));
  s2 = (int *) calloc (62, sizeof(int));

  for (i = 0; i < 100; i++)
    s1[i] = 0;
  free(s1);

  return 0;
}
